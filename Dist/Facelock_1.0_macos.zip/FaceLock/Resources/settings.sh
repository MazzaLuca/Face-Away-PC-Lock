#!/bin/bash

cd ../../../Resources/
java -jar Preferences.jar