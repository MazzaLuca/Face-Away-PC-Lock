#!/bin/bash
osascript -e 'tell application "System Events" to make login item at end with properties {path:"/Applications/FaceLock/FaceLock.app", hidden:false}'
