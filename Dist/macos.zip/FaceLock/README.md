##FACELOCK

Please note that the software works only if the entire folder is located under /Applications/.

Make sure to have installed Java, version 12.0.2 and Python 3.6.6 or 3.7.3, that is preinstalled in macOS 10.15.3.

To install Java 12.0.2 go to the following link.

https://www.oracle.com/java/technologies/javase/jdk12-archive-downloads.html#license-lightbox

Before running anything else run Setup.app.

Once the little gear in the menu bar show the completion of the installation you can run the other applications.