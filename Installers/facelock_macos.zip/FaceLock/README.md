##FACELOCK

Please note that the software works only if the entire folder is located under /Applications/.

Before running anything else run *Setup.app*

- *Luca Mazza*