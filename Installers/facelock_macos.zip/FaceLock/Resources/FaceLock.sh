#!/usr/bin/env bash 


cd ../../../Resources/

python3 faceCheck.py