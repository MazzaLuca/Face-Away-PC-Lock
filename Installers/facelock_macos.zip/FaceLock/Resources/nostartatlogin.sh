#!/bin/bash
osascript -e 'tell application "System Events" to delete login item "FaceLock"'
