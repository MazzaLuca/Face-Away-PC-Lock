#!/bin/bash
#Jonas Bertossa
# blocca lo schermo
export DISPLAY=:0.0
gnome-screensaver-command -l
