#!/bin/bash

cd ../../../Resources/

python3 faceCheck.py
